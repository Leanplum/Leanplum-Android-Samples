package com.leanplum.variablessample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.leanplum.Leanplum;
import com.leanplum.Var;
import com.leanplum.activities.LeanplumActivity;
import com.leanplum.annotations.Variable;
import com.leanplum.callbacks.VariablesChangedCallback;

public class MainActivity extends LeanplumActivity {

    private static final String ALARMBEHAVIOUR_SIMPLE = "SIMPLE";
    private static final String ALARMBEHAVIOUR_FULSCREEN_AUTO_SWITCH = "FULLSCREEN_AUTO_SWITCH";
    private static final String ALARMBEHAVIOUR_FULSCREEN_SUGGEST_SWITCH = "FULLSCREEN_SUGGEST_SWITCH";

    static Var<String> alarmBehaviour = Var.define("alarmBehaviour", ALARMBEHAVIOUR_SIMPLE);

    @Variable
    public static String anotherTest = ALARMBEHAVIOUR_FULSCREEN_SUGGEST_SWITCH;



    public void openAnotherActivity(View view) {
        Intent intent = new Intent(this, AnotherActivity.class);
        startActivity(intent);
    }

    public void openLPactivity(View view) {
        Intent intent = new Intent(this, AnotherLPactivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Leanplum.addVariablesChangedAndNoDownloadsPendingHandler(new VariablesChangedCallback() {
            @Override
            public void variablesChanged() {
                Log.i("#### ", alarmBehaviour.value());
                Log.i("#### ", anotherTest);
            }
        });

    }
}
