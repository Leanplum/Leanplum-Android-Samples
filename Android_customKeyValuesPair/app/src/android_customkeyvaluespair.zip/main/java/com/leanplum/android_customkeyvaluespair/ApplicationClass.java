package com.leanplum.android_customkeyvaluespair;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.leanplum.Leanplum;
import com.leanplum.LeanplumActivityHelper;
import com.leanplum.LeanplumPushNotificationCustomizer;
import com.leanplum.LeanplumPushService;
import com.leanplum.annotations.Parser;
import com.leanplum.callbacks.StartCallback;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by fede on 5/19/16.
 */
public class ApplicationClass extends Application {


    @Override
    public void onCreate() {

        Leanplum.setApplicationContext(this);
        Parser.parseVariables(this);
        LeanplumActivityHelper.enableLifecycleCallbacks(this);

        super.onCreate();

        if (BuildConfig.DEBUG) {
            Leanplum.setAppIdForDevelopmentMode("", "");
        } else {
            Leanplum.setAppIdForProductionMode("", "");
        }

        LeanplumPushService.setCustomizer(new LeanplumPushNotificationCustomizer() {
            //
            @Override
            public void customize(NotificationCompat.Builder builder, Bundle notificationPayload) {

                Log.i("#### ", String.valueOf(notificationPayload));

                URL urlLargeImageURL = null;
                URL urlBannerImageURL = null;
                Bitmap largeImage;
                Bitmap androidBanner;

                String urlLargeImageString = notificationPayload.getString("largeImageURL");
                String urlBannerImageString = notificationPayload.getString("bannerImageURL");

                if ((urlLargeImageString != null) && (urlBannerImageString != null)){
                    try {

                        urlLargeImageURL = new URL(urlLargeImageString);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }

                    try {
                        urlBannerImageURL = new URL(urlBannerImageString);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }

                    try {
                        largeImage = BitmapFactory.decodeStream(urlLargeImageURL.openConnection().getInputStream());
                        builder.setLargeIcon(largeImage);
                    } catch (java.io.IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        androidBanner = BitmapFactory.decodeStream(urlBannerImageURL.openConnection().getInputStream());
                        builder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(androidBanner));
                    } catch (java.io.IOException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    Log.i("###", "Nothing to customize here, move along");
                }

            }

        });

        LeanplumPushService.setGcmSenderId(LeanplumPushService.LEANPLUM_SENDER_ID);

        Leanplum.start(this);
    }
}
